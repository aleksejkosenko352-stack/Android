fun getScoreMessage(): String {
    var score = 100
    // score = "100" // Це викличе помилку компіляції!
    // TODO: Поверніть рядок "Your score is 100" використовуючи поточне значення score
    var text: String = "Your score is $score"
    return text
}