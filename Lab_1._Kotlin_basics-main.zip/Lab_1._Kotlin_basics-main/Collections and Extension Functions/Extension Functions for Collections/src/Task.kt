// TODO: Оголосіть fun List<Int>.sumOdd(): Int
fun List<Int>.sumOdd(): Int{
    var sumOdd = 0
    for (item in this)
        if (item % 2 != 0)
            sumOdd += item
    return sumOdd
}