fun generateGreeting(name: String?): String {
    // TODO: Обробіть null та порожній рядок. Значення за замовчуванням - "Guest".
    // Поверніть рядок формату "Welcome, Name!"
    return "Welcome, ${name?.takeIf { it.isNotEmpty() } ?: "Guest"}!"
}